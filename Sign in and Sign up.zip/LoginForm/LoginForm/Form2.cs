﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\CG-DTE\\Documents\\LoginDb.mdf;Integrated Security=True;Connect Timeout=30");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (u_name.Text != ""   && password.Text != "") 
            {
                string query = "select count(*) from RegistrationTbl where email='" + u_name.Text + "' and " + "password = '" + password.Text + "'";
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                int v = (int)command.ExecuteScalar();
                if( v!= 1)
                {
                    MessageBox.Show("error username or passwords", "Error!");
                }
                else
                {
                    MessageBox.Show("welcome to your profile");
                    u_name.Text = "";
                    password.Text = "";
                }
            }
            else
            {
                MessageBox.Show("first fill all section");
            }
            connection.Close();

        }

        private void rem_CheckedChanged(object sender, EventArgs e)
        {
            if (rem.Checked)
            {
                password.UseSystemPasswordChar = false;
                

            }
            else
            {
                password.UseSystemPasswordChar = true;
                
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void u_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            DateTime dt  = DateTime.Now;
            label4.Text = dt.ToString();
        }
    }
}
