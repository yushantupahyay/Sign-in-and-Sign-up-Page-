﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\CG-DTE\\Documents\\LoginDb.mdf;Integrated Security=True;Connect Timeout=30");

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(first_name.Text != "" && last_name.Text != ""  && date.Text !=""  &&   gender.Text != ""  &&     address.Text  != ""  && email.Text != "" &&  password.Text != ""  &&  confirm.Text != "")
                {
                    if(password.Text == confirm.Text)
                    {
                        int v = check(email.Text);
                        if(v!=1)
                        {
                            connection.Open();
                            SqlCommand command = new SqlCommand("insert into  RegistrationTbl values (@f_name,@l_name," + "@b_date,@gender, @address,@email,@password)", connection);
                            command.Parameters.AddWithValue("@f_name", first_name.Text);
                            command.Parameters.AddWithValue("@l_name", last_name.Text);
                            command.Parameters.AddWithValue("@b_date", Convert.ToDateTime(date.Text));
                            command.Parameters.AddWithValue("@gender", gender.Text);
                            command.Parameters.AddWithValue("@address", address.Text);
                            command.Parameters.AddWithValue("@email", email.Text);
                            command.Parameters.AddWithValue("@password", password.Text);
                            command.ExecuteNonQuery();
                            connection.Close();
                            MessageBox.Show("Register successfully");
                            first_name.Text = "";
                            last_name.Text = "";
                            gender.Text = "";
                            address.Text = "";
                            email.Text = "";
                            password.Text = "";
                            confirm.Text = "";


                        }
                        else
                        {
                            MessageBox.Show("you are already register");
                        }
                    }
                    else
                    {
                        MessageBox.Show("password does not match");
                    }

                }
                else
                {
                    MessageBox.Show("first fill all the section");
                }

                   
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.Message);
            }
        }
        int check(string email)
        {
            connection.Open();
            string query = "select count(*) from RegistrationTbl where email= '" + email +"'";
            SqlCommand command = new SqlCommand(query, connection);
            int v = (int)command.ExecuteScalar();
            connection.Close();
            return v;

        

       // private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }

        private void rem_CheckedChanged(object sender, EventArgs e)
        {
            if (rem.Checked)
            {
                password.UseSystemPasswordChar = false;
                confirm.UseSystemPasswordChar = false  ;

            }
            else
            {
                password.UseSystemPasswordChar = true;
                confirm.UseSystemPasswordChar = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
          
            this.Hide();
            Form2 form2 = new Form2(); 
            form2.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    }